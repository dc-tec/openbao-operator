# OpenBao Operator edge chart

Evaluation build from commit 12f2ea3aaaa0f84a0d5e499d1c2d459a3fe6fa5c. Chart version: 0.5.0-edge.35778352942.1.g12f2ea3aaaa0.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
