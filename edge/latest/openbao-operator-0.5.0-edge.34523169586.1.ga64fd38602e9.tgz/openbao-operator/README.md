# OpenBao Operator edge chart

Evaluation build from commit a64fd38602e9ccd1ee505838c095333b56bb2a51. Chart version: 0.5.0-edge.34523169586.1.ga64fd38602e9.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
