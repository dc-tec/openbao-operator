# OpenBao Operator edge chart

Evaluation build from commit 6518d2b17b8e92e11f2f43024638c84e2152ac7c. Chart version: 0.5.0-edge.35868756381.1.g6518d2b17b8e.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
