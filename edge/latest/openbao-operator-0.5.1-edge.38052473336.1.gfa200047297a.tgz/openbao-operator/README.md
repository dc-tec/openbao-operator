# OpenBao Operator edge chart

Evaluation build from commit fa200047297a93d945ee0dd0f05c39900ad08603. Chart version: 0.5.1-edge.38052473336.1.gfa200047297a.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
