# OpenBao Operator edge chart

Evaluation build from commit db9578767777770fd5eea2ecf7ff53fb7c60a42b. Chart version: 0.5.1-edge.37943496397.1.gdb9578767777.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
