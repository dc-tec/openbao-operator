# OpenBao Operator edge chart

Evaluation build from commit 31a34abe7c9eea13e9579e8597b56e22084a0343. Chart version: 0.5.0-edge.34960377548.1.g31a34abe7c9e.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
