# OpenBao Operator edge chart

Evaluation build from commit fa97eae052b274f5d9fe9079b489db82bc31454a. Chart version: 0.5.1-edge.38037028884.1.gfa97eae052b2.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
