# OpenBao Operator edge chart

Evaluation build from commit 4e92d85bf5dfc9592f50a0450c01520eb953da23. Chart version: 0.5.1-edge.37936534209.1.g4e92d85bf5df.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
