# OpenBao Operator edge chart

Evaluation build from commit 4822e595eed80af436eebb314aaa9f01c09da223. Chart version: 0.5.1-edge.36067092998.1.g4822e595eed8.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
