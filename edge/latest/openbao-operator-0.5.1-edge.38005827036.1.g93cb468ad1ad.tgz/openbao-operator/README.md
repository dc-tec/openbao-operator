# OpenBao Operator edge chart

Evaluation build from commit 93cb468ad1ad822e7f69259238f6bbca0d63d7ee. Chart version: 0.5.1-edge.38005827036.1.g93cb468ad1ad.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
