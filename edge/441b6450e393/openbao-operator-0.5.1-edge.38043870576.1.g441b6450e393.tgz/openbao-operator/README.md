# OpenBao Operator edge chart

Evaluation build from commit 441b6450e393a84f3880d17107dcbc774690d039. Chart version: 0.5.1-edge.38043870576.1.g441b6450e393.

Install this chart from oci://ghcr.io/kubebao/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://docs.kubebao.org/next/docs/get-started/install/ for installation and CRD upgrade steps.
