# OpenBao Operator edge chart

Evaluation build from commit b3bd17a8f18e5f70ceafe3cf941586a47062922a. Chart version: 0.5.1-edge.36233974892.1.gb3bd17a8f18e.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
