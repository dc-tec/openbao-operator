# OpenBao Operator edge chart

Evaluation build from commit 017a5bd7276ac7405a8a1ba4b994a436cb889ce2. Chart version: 0.5.0-edge.35766439808.1.g017a5bd7276a.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
