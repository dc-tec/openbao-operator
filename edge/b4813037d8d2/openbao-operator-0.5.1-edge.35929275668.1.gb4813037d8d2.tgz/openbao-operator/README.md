# OpenBao Operator edge chart

Evaluation build from commit b4813037d8d2a78ce22018aecfa3baafed64c937. Chart version: 0.5.1-edge.35929275668.1.gb4813037d8d2.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
