# OpenBao Operator edge chart

Evaluation build from commit 850d02d204a88745805d6edfc3235a44242cc5c1. Chart version: 0.5.0-edge.35622221026.1.g850d02d204a8.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
