# OpenBao Operator edge chart

Evaluation build from commit 94b18f2e3a2dde49550adad43d095220d4dac945. Chart version: 0.5.0-edge.35920479763.1.g94b18f2e3a2d.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
