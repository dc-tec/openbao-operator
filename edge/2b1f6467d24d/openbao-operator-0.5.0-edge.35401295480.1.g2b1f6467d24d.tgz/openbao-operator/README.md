# OpenBao Operator edge chart

Evaluation build from commit 2b1f6467d24d671f09b2d52cd8da686315db1d3f. Chart version: 0.5.0-edge.35401295480.1.g2b1f6467d24d.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
