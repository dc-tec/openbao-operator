# OpenBao Operator edge chart

Evaluation build from commit db025e3338620dd2a5af830e8196ce5b1b8f9b4c. Chart version: 0.5.1-edge.35964923578.1.gdb025e333862.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
