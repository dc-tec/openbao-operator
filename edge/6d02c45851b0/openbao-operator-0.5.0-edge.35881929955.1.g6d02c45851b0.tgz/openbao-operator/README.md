# OpenBao Operator edge chart

Evaluation build from commit 6d02c45851b0d26fa027cd7060a9d7a26e684551. Chart version: 0.5.0-edge.35881929955.1.g6d02c45851b0.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
