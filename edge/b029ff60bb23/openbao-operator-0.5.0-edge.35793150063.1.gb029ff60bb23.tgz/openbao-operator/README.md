# OpenBao Operator edge chart

Evaluation build from commit b029ff60bb2354b11a40ee9ed4b4544adcc8e3ff. Chart version: 0.5.0-edge.35793150063.1.gb029ff60bb23.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
