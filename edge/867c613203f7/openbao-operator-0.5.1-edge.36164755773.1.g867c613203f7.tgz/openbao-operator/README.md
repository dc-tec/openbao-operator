# OpenBao Operator edge chart

Evaluation build from commit 867c613203f7ffa80f70f97843c0b312d95ff74e. Chart version: 0.5.1-edge.36164755773.1.g867c613203f7.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
